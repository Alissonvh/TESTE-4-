import { Request, Response, NextFunction } from 'express';
import { AuthService } from '../services/auth.service';
import { LoginInput, RegisterInput } from '../schemas/auth.schema';
import { AppError } from '../utils/app-error';

export class AuthController {
  private authService: AuthService;

  constructor() {
    this.authService = new AuthService();
  }

  register = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const userData: RegisterInput = req.body;
      const user = await this.authService.register(userData);
      
      return res.status(201).json({
        success: true,
        data: user,
        message: 'User registered successfully'
      });
    } catch (error) {
      return next(error);
    }
  };

  login = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const credentials: LoginInput = req.body;
      const result = await this.authService.login(credentials);
      
      return res.status(200).json({
        success: true,
        data: result,
        message: 'Login successful'
      });
    } catch (error) {
      return next(error);
    }
  };

  refreshToken = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { refreshToken } = req.body;
      
      if (!refreshToken) {
        throw new AppError('Refresh token is required', 400);
      }
      
      const tokens = await this.authService.refreshToken(refreshToken);
      
      return res.status(200).json({
        success: true,
        data: tokens,
        message: 'Token refreshed successfully'
      });
    } catch (error) {
      return next(error);
    }
  };

  logout = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { refreshToken } = req.body;
      
      if (!refreshToken) {
        throw new AppError('Refresh token is required', 400);
      }
      
      await this.authService.logout(refreshToken);
      
      return res.status(200).json({
        success: true,
        message: 'Logout successful'
      });
    } catch (error) {
      return next(error);
    }
  };
}