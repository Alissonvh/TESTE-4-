import { Request, Response, NextFunction } from 'express';
import { UserService } from '../services/user.service';
import { UpdateUserInput } from '../schemas/user.schema';
import { AppError } from '../utils/app-error';
import { AuthRequest } from '../types/auth.types';

export class UserController {
  private userService: UserService;

  constructor() {
    this.userService = new UserService();
  }

  getProfile = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const authReq = req as AuthRequest;
      const userId = authReq.user?.id;
      
      if (!userId) {
        throw new AppError('User ID is required', 400);
      }
      
      const user = await this.userService.getById(userId);
      
      return res.status(200).json({
        success: true,
        data: user,
        message: 'User profile retrieved successfully'
      });
    } catch (error) {
      return next(error);
    }
  };

  updateProfile = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const authReq = req as AuthRequest;
      const userId = authReq.user?.id;
      
      if (!userId) {
        throw new AppError('User ID is required', 400);
      }
      
      const userData: UpdateUserInput = req.body;
      const updatedUser = await this.userService.update(userId, userData);
      
      return res.status(200).json({
        success: true,
        data: updatedUser,
        message: 'User profile updated successfully'
      });
    } catch (error) {
      return next(error);
    }
  };
}