import { Request, Response, NextFunction } from 'express';
import { AppError } from '../utils/app-error';
import { AuthRequest } from '../types/auth.types';

export const tenantMiddleware = (req: Request, res: Response, next: NextFunction) => {
  try {
    const authReq = req as AuthRequest;
    const tenantId = authReq.user?.tenantId;
    
    if (!tenantId) {
      throw new AppError('Tenant ID is required', 403);
    }
    
    authReq.tenantId = tenantId;
    next();
  } catch (error) {
    return next(error);
  }
};