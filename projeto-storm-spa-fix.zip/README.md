# Projeto Storm - Fullstack (Correção do Erro 404)

Este projeto contém o frontend e backend do Projeto Storm, estruturado para deploy na Vercel, com correções para o erro 404.

## Estrutura do Projeto

- `/frontend` - Aplicação React com Vite
- `/backend` - API Node.js com Express

## Correções Realizadas

1. **Corrigido o conflito de dependências** entre `date-fns` e `react-day-picker`
2. **Ajustado o arquivo vercel.json** para configurar corretamente o build na Vercel
3. **Corrigido o erro 404** ajustando o buildCommand para executar diretamente na pasta frontend

## Como Fazer o Deploy

### GitHub

1. Crie um repositório no GitHub
2. Faça o upload deste projeto para o repositório
3. Certifique-se de que todos os arquivos estejam incluídos, especialmente o `vercel.json` na raiz

### Vercel

1. Acesse a [Vercel](https://vercel.com)
2. Importe o projeto do GitHub
3. A Vercel detectará automaticamente as configurações do projeto
4. Clique em "Deploy" para iniciar o processo

## Desenvolvimento Local

Para executar o projeto localmente:

```bash
# Instalar dependências
npm install

# Executar em modo de desenvolvimento
npm run dev

# Construir para produção
npm run build
```

## Solução do Erro 404

O erro 404 foi corrigido ajustando o arquivo `vercel.json` para:

1. Executar o build diretamente na pasta frontend
2. Garantir que o outputDirectory aponte corretamente para frontend/dist
3. Configurar os rewrites para direcionar todas as rotas para o index.html (SPA)
